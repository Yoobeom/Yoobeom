PrimeTime Tcl Cookbook v1.0
=================================

Contents
  primetime-tcl-cookbook.pdf   the book
  scripts/*.tcl                41 standalone scripts referenced in the book

Quick start (inside pt_shell, after link_design and update_timing):
  foreach f [glob ./scripts/*.tcl] { source $f }
  path_table -group CLK -max_paths 100
  clock_pair_matrix
  bucket_violators -depth 2 -out violators.csv

Scripts that begin with a configuration block (02_session_setup.tcl,
10_dmsa_setup.tcl) are templates: copy and edit, do not source directly.

License: single-organisation use. Do not redistribute the PDF.
Support: reply to your purchase receipt with the script name and the
pt_shell version; attribute name differences between releases are the
most common issue and are quick to resolve.
